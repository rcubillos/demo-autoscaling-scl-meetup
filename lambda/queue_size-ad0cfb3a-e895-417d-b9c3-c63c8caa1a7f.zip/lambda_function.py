import boto3
from datetime import datetime

sqs_client = boto3.resource('sqs')

client = boto3.client('cloudwatch')

def lambda_handler(event, context):
    global sqs_client
    
    queue = sqs_client.get_queue_by_name(QueueName=event['QueueName'])
    
    write_metric(event['QueueName'],int(queue.attributes.get("ApproximateNumberOfMessages")))
    
def write_metric(queueName,count):
    global client
    response = client.put_metric_data(
    Namespace='Custom/Queue',
    MetricData=[
        {
            'MetricName': 'QueueCount',
            'Dimensions': [
                {
                    'Name': 'Queue',
                    'Value': queueName
                },
            ],
            'Timestamp': datetime.now(),
            'Value': count,
            'Unit': 'Count'
        },
    ]
)